import React, { createContext, useContext, useMemo, useState } from 'react'
import { PRODUCTS } from '../data/products.js'

const CartContext = createContext(null)
export const useCart = () => useContext(CartContext)

export default function CartProvider({children}){
  const [items, setItems] = useState({}) // {code: qty}

  const add = (code, qty=1) =>
    setItems(prev => ({ ...prev, [code]: (prev[code] || 0) + qty }))

  const remove = (code) =>
    setItems(prev => {
      const n = { ...prev }
      delete n[code]
      return n
    })

  const setQty = (code, qty) =>
    setItems(prev => {
      const value = Math.max(0, qty)
      const n = { ...prev }
      if (value <= 0) {
        delete n[code]
      } else {
        n[code] = value
      }
      return n
    })

  const clearCart = () => setItems({})

  const list = useMemo(
    () =>
      Object.entries(items).map(([code, qty]) => {
        const p = PRODUCTS.find(x => x.code === code)
        return { ...p, qty, subtotal: (p?.price || 0) * qty }
      }),
    [items]
  )

  const count = useMemo(
    () => Object.values(items).reduce((a, b) => a + b, 0),
    [items]
  )
  const total = useMemo(
    () => list.reduce((a, b) => a + b.subtotal, 0),
    [list]
  )

  const value = { items, list, count, total, add, remove, setQty, clearCart }
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}
