import { PRODUCTS } from '../data/products.js'
import { fmtCLP } from '../utils.js'
import { Link } from 'react-router-dom'

export default function AdminProducts(){
  return (
    <div className="container my-4">
      <div className="row g-3">
        <div className="col-12 col-lg-3">
          <div className="card p-3">
            <h6 className="mb-3">Productos</h6>
            <Link className="btn btn-outline-primary w-100" to="/admin">Volver</Link>
          </div>
        </div>
        <div className="col">
          <h1>Listado de Productos</h1>
          <div className="table-responsive card">
            <table className="table mb-0">
              <thead>
                <tr><th>Código</th><th>Nombre</th><th>Categoría</th><th>Precio</th><th>Stock</th></tr>
              </thead>
              <tbody>
                {PRODUCTS.map((p,i)=>(
                  <tr key={p.code}>
                    <td>{p.code}</td>
                    <td>{p.name}</td>
                    <td>{p.category}</td>
                    <td>{fmtCLP(p.price)}</td>
                    <td>{[150,200,250,100,80,120,50,60,90][i % 9]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
