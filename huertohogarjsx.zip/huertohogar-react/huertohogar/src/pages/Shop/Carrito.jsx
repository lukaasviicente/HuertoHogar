import { Link } from 'react-router-dom'
import { useCart } from '../../Context/cartcontext.jsx'
import { fmtCLP } from '../../utils.js'

export default function Carrito(){
  const { list, total, setQty, remove } = useCart()

  return (
    <div className="container my-4">
      <h1>Carrito</h1>
      {list.length===0 && <p>Tu carrito está vacío.</p>}
      {list.length>0 &&
        <div className="row g-3">
          <div className="col-12 col-lg-8">
            {list.map(item => (
              <div key={item.code} className="card p-3 mb-2">
                <div className="d-flex align-items-center gap-3">
                  <img src={item.img} alt="" style={{width:84,height:64}} />
                  <div className="flex-grow-1">
                    <div className="fw-semibold">{item.name}</div>
                    <div className="text-muted small">{item.category}</div>
                  </div>
                  <input type="number" className="form-control" style={{width:100}}
                         min="0" value={item.qty}
                         onChange={(e)=>setQty(item.code, parseInt(e.target.value||0))} />
                  <div className="fw-semibold">{fmtCLP(item.subtotal)}</div>
                  <button className="btn btn-outline-secondary btn-sm" onClick={()=>remove(item.code)}>Quitar</button>
                </div>
              </div>
            ))}
          </div>
          <div className="col-12 col-lg-4">
            <div className="card p-3">
              <div className="d-flex justify-content-between"><span>Total</span><strong>{fmtCLP(total)}</strong></div>
              <Link className="btn btn-primary mt-3 w-100" to="/checkout">Ir a pagar</Link>
            </div>
          </div>
        </div>
      }
    </div>
  )
}
