import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { fmtCLP } from '../../utils.js'

export default function Boleta() {
  const [order, setOrder] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem('huertohogar_last_order')
      if (raw) {
        setOrder(JSON.parse(raw))
      }
    } catch (err) {
      console.error('Error leyendo última orden', err)
    }
  }, [])

  if (!order) {
    return (
      <div className="container my-4">
        <h1>Boleta</h1>
        <p>No hay ninguna compra reciente.</p>
        <button className="btn btn-primary" onClick={() => navigate('/products')}>
          Volver a la tienda
        </button>
      </div>
    )
  }

  return (
    <div className="container my-4" style={{ maxWidth: 900 }}>
      <div className="card p-4">
        <header className="d-flex justify-content-between align-items-start mb-4">
          <div>
            <h1 className="h3 mb-1">Boleta electrónica</h1>
            <div className="text-muted small">HuertoHogar · Frescura directa del campo a tu mesa</div>
          </div>
          <div className="text-end small">
            <div><strong>Fecha:</strong> {order.date}</div>
            <div><strong>Nº orden:</strong> {order.id}</div>
          </div>
        </header>

        <section className="mb-4">
          <h2 className="h5">Datos del cliente</h2>
          <div className="row">
            <div className="col-md-6">
              <div><strong>Nombre:</strong> {order.name}</div>
              <div><strong>Correo:</strong> {order.email}</div>
            </div>
            <div className="col-md-6">
              <div><strong>Domicilio:</strong> {order.address}</div>
              <div><strong>Comuna:</strong> {order.comuna}</div>
              <div><strong>Región:</strong> {order.region}</div>
            </div>
          </div>
        </section>

        <section className="mb-4">
          <h2 className="h5">Detalle de la compra</h2>
          <div className="table-responsive">
            <table className="table table-sm align-middle">
              <thead>
                <tr>
                  <th>Producto</th>
                  <th className="text-center">Cantidad</th>
                  <th className="text-end">Precio unitario</th>
                  <th className="text-end">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map(item => (
                  <tr key={item.code}>
                    <td>{item.name}</td>
                    <td className="text-center">{item.qty}</td>
                    <td className="text-end">{fmtCLP(item.price)}</td>
                    <td className="text-end">{fmtCLP(item.subtotal)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <th colSpan={3} className="text-end">
                    Total pagado:
                  </th>
                  <th className="text-end">{fmtCLP(order.total)}</th>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>

        {order.comment && (
          <section className="mb-3">
            <h2 className="h6">Comentario del cliente</h2>
            <p className="mb-0">{order.comment}</p>
          </section>
        )}

        <div className="d-flex justify-content-between align-items-center mt-4">
          <small className="text-muted">
            Gracias por comprar en HuertoHogar. Este comprobante es válido sólo para fines académicos
            (proyecto universitario).
          </small>
          <button className="btn btn-outline-primary" onClick={() => navigate('/products')}>
            Volver a la tienda
          </button>
        </div>
      </div>
    </div>
  )
}
