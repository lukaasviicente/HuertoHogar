import { useCart } from '../../Context/cartcontext.jsx'
import { fmtCLP } from '../../utils.js'

export default function Checkout(){
  const { total } = useCart()
  return (
    <div className="container container-narrow my-4">
      <h1>Checkout</h1>
      <div className="card p-4">
        <div className="mb-3">
          <label className="form-label">Nombre</label>
          <input className="form-control" placeholder="Nombre y apellido" />
        </div>
        <div className="mb-3">
          <label className="form-label">Dirección</label>
          <input className="form-control" placeholder="Calle 123, Comuna" />
        </div>
        <div className="mb-3">
          <label className="form-label">Correo</label>
          <input type="email" className="form-control" placeholder="usuario@duoc.cl" />
        </div>
        <div className="d-flex justify-content-between">
          <div>Total</div><strong>{fmtCLP(total)}</strong>
        </div>
        <button className="btn btn-primary mt-3 w-100">Pagar</button>
      </div>
    </div>
  )
}