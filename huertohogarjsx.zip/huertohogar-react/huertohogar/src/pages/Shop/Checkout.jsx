import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useCart } from '../../Context/cartcontext.jsx'
import { fmtCLP } from '../../utils.js'

export default function Checkout(){
  const { list, total, clearCart } = useCart()
  const navigate = useNavigate()

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [address, setAddress] = useState('')
  const [region, setRegion] = useState('')
  const [comuna, setComuna] = useState('')
  const [comment, setComment] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    setError('')

    if (!name || !email || !address || !region || !comuna) {
      setError('Completa todos los campos obligatorios.')
      return
    }
    if (list.length === 0) {
      setError('Tu carrito está vacío.')
      return
    }

    const order = {
      id: 'HH-' + Date.now(),
      date: new Date().toLocaleString('es-CL'),
      name,
      email,
      address,
      region,
      comuna,
      comment,
      items: list.map(p => ({
        code: p.code,
        name: p.name,
        qty: p.qty,
        price: p.price,
        subtotal: p.subtotal
      })),
      total
    }

    try {
      window.localStorage.setItem('huertohogar_last_order', JSON.stringify(order))
    } catch (err) {
      console.error('No se pudo guardar la boleta', err)
    }

    clearCart()
    navigate('/boleta')
  }

  return (
    <div className="container my-4" style={{maxWidth:900}}>
      <h1 className="mb-3">Datos de envío y pago</h1>

      {list.length === 0 && (
        <div className="alert alert-warning">
          Tu carrito está vacío. Agrega productos antes de continuar.
        </div>
      )}

      {error && <div className="alert alert-danger">{error}</div>}

      <div className="row g-4">
        <div className="col-md-7">
          <form className="card p-4" onSubmit={handleSubmit}>
            <h2 className="h5 mb-3">Datos del comprador</h2>

            <div className="mb-3">
              <label className="form-label">Nombre completo</label>
              <input
                type="text"
                className="form-control"
                value={name}
                onChange={e=>setName(e.target.value)}
                required
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Correo electrónico</label>
              <input
                type="email"
                className="form-control"
                placeholder="usuario@duoc.cl"
                value={email}
                onChange={e=>setEmail(e.target.value)}
                required
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Domicilio</label>
              <input
                type="text"
                className="form-control"
                placeholder="Calle, número, depto."
                value={address}
                onChange={e=>setAddress(e.target.value)}
                required
              />
            </div>

            <div className="row mb-3">
              <div className="col-md-6">
                <label className="form-label">Región</label>
                <input
                  type="text"
                  className="form-control"
                  value={region}
                  onChange={e=>setRegion(e.target.value)}
                  required
                />
              </div>
              <div className="col-md-6">
                <label className="form-label">Comuna</label>
                <input
                  type="text"
                  className="form-control"
                  value={comuna}
                  onChange={e=>setComuna(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">Comentario para el repartidor (opcional)</label>
              <textarea
                className="form-control"
                rows="3"
                value={comment}
                onChange={e=>setComment(e.target.value)}
              />
            </div>

            <button className="btn btn-success w-100" type="submit" disabled={list.length===0}>
              Confirmar y pagar
            </button>
          </form>
        </div>

        <div className="col-md-5">
          <div className="card p-4">
            <h2 className="h5 mb-3">Resumen de la compra</h2>
            {list.map(item => (
              <div key={item.code} className="d-flex justify-content-between mb-2">
                <div>
                  <div className="fw-semibold">{item.name}</div>
                  <div className="text-muted small">
                    {item.qty} x {fmtCLP(item.price)}
                  </div>
                </div>
                <div className="fw-semibold">{fmtCLP(item.subtotal)}</div>
              </div>
            ))}
            <hr />
            <div className="d-flex justify-content-between">
              <span className="fw-semibold">Total</span>
              <span className="fw-bold">{fmtCLP(total)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
