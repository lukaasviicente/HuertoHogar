import { Link, useLocation } from 'react-router-dom'
import { useMemo } from 'react'
import { PRODUCTS } from '../../data/products.js'
import { fmtCLP } from '../../utils.js'
import { useCart } from '../../Context/cartcontext.jsx'

export default function Products(){
  const { add } = useCart()
  const q = new URLSearchParams(useLocation().search)
  const cat = q.get('cat')

  const list = useMemo(()=> cat ? PRODUCTS.filter(p=>p.category===cat) : PRODUCTS, [cat])
  const cats = [...new Set(PRODUCTS.map(p=>p.category))]

  return (
    <div className="container my-4">
      <div className="d-flex gap-2 mb-3">
        <Link className={`btn ${!cat?'btn-primary':'btn-outline-primary'}`} to="/products">Todas</Link>
        {cats.map(c=>(
          <Link key={c} className={`btn ${cat===c?'btn-primary':'btn-outline-primary'}`} to={`/products?cat=${encodeURIComponent(c)}`}>{c}</Link>
        ))}
      </div>

      <div className="row row-cols-1 row-cols-md-3 g-3">
        {list.map(p=>(
          <div key={p.code} className="col">
            <div className="card h-100 product-card hover">
              <img src={p.img} className="card-img-top" alt={p.name} />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{p.name}</h5>
                <div className="category mb-2">{p.category}</div>
                <div className="mt-auto d-flex justify-content-between align-items-center">
                  <div className="price">{fmtCLP(p.price)} <span className="unit">{p.unit}</span></div>
                  <div className="d-flex gap-2">
                    <Link className="btn btn-sm btn-outline-primary" to={`/producto/${p.code}`}>Ver detalle</Link>
                    <button className="btn btn-sm btn-primary" onClick={()=>add(p.code,1)}>Añadir</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
